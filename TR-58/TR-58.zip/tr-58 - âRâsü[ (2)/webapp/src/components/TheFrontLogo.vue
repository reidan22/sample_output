<template>
  <div class="logo-text">
    <p>GUHIT</p>
    <span>
      is an online art sharing hub.<br />
      Created by Dan for TR-58.
    </span>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
span {
  color: #b3cde0;
  font-size: 0.85rem;
}
p {
  font-family: Brushes;
  font-size: 3rem;
  color: #b3cde0;
}
</style>
