<template>
  <div></div>
</template>

<script>
export default {};
</script>

<style scoped>
div {
  position: absolute;
  background-color: #005b96;
  height: 100vh;
  overflow: hidden;
}
</style>
