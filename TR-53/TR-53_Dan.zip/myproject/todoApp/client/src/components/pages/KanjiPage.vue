<template>
  <h1>漢字</h1>
</template>

<script>
export default {};
</script>

<style scoped>
* {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
