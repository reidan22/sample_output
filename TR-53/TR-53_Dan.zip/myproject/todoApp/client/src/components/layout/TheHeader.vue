<template>
  <header>Study 日本語</header>
</template>

<script>
export default {};
</script>

<style scoped>
header {
  width: 100%;
  height: 7rem;
  background-color: #5cdb95;
  color: #05386b;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 2rem;
  margin: 0.5rem auto;
  padding-top: 1rem;
}
</style>
